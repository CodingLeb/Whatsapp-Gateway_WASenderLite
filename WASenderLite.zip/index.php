<?php
require_once('helper/koneksi.php');
header('Location:' . $base_url . 'pages/login.php');
